This resource pack provides mandatory assets for the Magicality Mod Pack and needs to be activated to play with the highest priority.

The assets under assets\defeatedcrow\textures\items are modified versions of yuzu.png, provided under the CC-BY-NC license by defeatedcrow.
As such, they are also licensed under the same terms.
Source: Apple Milk & Tea, http://forum.minecraftuser.jp/viewtopic.php?t=17657

Chisel textures are provided under the GPLv2. The are used unmodified, only swapped iron and diamond chisel.

Assets for AgriCraft:
* Tea, Cassis, Camellia & Kumquat textures are derivatives of textures from Apple, Milk and Tea (see above)
* Chrysalis textures were done for this pack by Belgabor

Item textures for the gem armour crafting steps and twilight forest core were done by Prof. Flaxbeard